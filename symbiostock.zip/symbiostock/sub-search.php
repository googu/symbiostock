<div class="alert alert-info "> 
    <span class="alignleft"><?php echo symbiostock_directory_link($text = '', false, false) ?></span>    
    <h3><?php _e('Extended Network Directory', 'symbiostock') ?></h3>    
    <p class="text-info"><?php _e('See more image authors: ', 'symbiostock') ?> <strong><a title="<?php _e('See more image authors: ', 'symbiostock') ?>" href="<?php echo symbiostock_directory_link($text = '', true) ?>" ><?php _e('Symbiostock Author Directory', 'symbiostock') ?></a> </strong></p>    
    <div class="clearfix">
        <br />
    </div>
</div>
